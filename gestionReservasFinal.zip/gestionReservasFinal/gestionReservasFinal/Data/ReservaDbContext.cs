﻿using gestionReservasFinal.Models;
using Microsoft.EntityFrameworkCore;

namespace gestionReservasFinal.Data
{
    public class ReservasDbContext : DbContext
    {
        public DbSet<reserva> Reservas { get; set; }

        public ReservasDbContext(DbContextOptions<ReservasDbContext> options)
            : base(options)
        { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<reserva>()
            .HasOne(r => r.Usser)
            .WithMany()
            .HasForeignKey(r => r.Id_usuario)
            .OnDelete(DeleteBehavior.Restrict);
        }

    }
}
