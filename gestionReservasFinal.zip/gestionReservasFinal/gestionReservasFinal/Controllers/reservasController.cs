﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using gestionReservasFinal.Data;
using gestionReservasFinal.Models;
using Microsoft.AspNetCore.Authorization;

namespace gestionReservasFinal.Controllers
{
    [Authorize]
    public class reservasController : Controller
    {
        private readonly ReservasDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;

        public reservasController(ReservasDbContext context, UserManager<IdentityUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }
        public async Task<IActionResult> HistoricoReservas(string buscar)
        {
            var user = await _userManager.GetUserAsync(User);

            IQueryable<reserva> reservasQuery = _context.Reservas
                .IgnoreQueryFilters()
                .Include(r => r.Usser)
                .Where(r => r.FechaFinal < DateTime.Now);

            if (!await _userManager.IsInRoleAsync(user, "Admin"))
            {
                reservasQuery = reservasQuery.Where(r => r.Id_usuario == user.Id);
            }
            if (!string.IsNullOrWhiteSpace(buscar))
            {
                buscar = char.ToUpper(buscar[0]) + buscar.Substring(1).ToLower();

                reservasQuery = reservasQuery.Where(r =>
                    r.Usser.NormalizedEmail.Contains(buscar.ToUpper()));
            }
            var reservas = await reservasQuery.ToListAsync();
            ViewBag.SearchTerm = buscar;
            return View(reservas);
        }

        // GET: reservas
        public async Task<IActionResult> Index(string buscar)
        {
            var user = await _userManager.GetUserAsync(User);

            IQueryable<reserva> reservasQuery = _context.Reservas
                .IgnoreQueryFilters()
                .Include(r => r.Usser);

            if (!await _userManager.IsInRoleAsync(user, "Admin"))
            {
                reservasQuery = reservasQuery.Where(r => r.Id_usuario == user.Id);
            }
            if (!string.IsNullOrWhiteSpace(buscar))
            {
                buscar = char.ToUpper(buscar[0]) + buscar.Substring(1).ToLower();

                reservasQuery = reservasQuery.Where(r =>
                    r.Usser.NormalizedEmail.Contains(buscar.ToUpper()));
            }
            var reservas = await reservasQuery.ToListAsync();
            ViewBag.SearchTerm = buscar;
            return View(reservas);
        }

        // GET: reservas/Details/5
        public async Task<IActionResult> Confirmacion(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reserva = await _context.Reservas
                .Include(r => r.Usser)
                .FirstOrDefaultAsync(m => m.Id_reserva == id);
            if (reserva == null)
            {
                return NotFound();
            }

            return View(reserva);
        }



        // GET: reservas/Create
        public IActionResult Create()
        {
            ViewData["Id_usuario"] = new SelectList(_context.Set<IdentityUser>(), "Id", "Id");
            return View();
        }

        // POST: reservas/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id_reserva,Numero_Plaza,FechaInicio,FechaFinal,Id_usuario,PrecioTotal")] reserva reserva)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return Challenge();
            }
            reserva.Id_usuario = user.Id;
            var existeReserva = await _context.Reservas.AnyAsync(r => r.Id_usuario == user.Id);

            if (!existeReserva)
            {
                reserva.Usser = user;
            }
            var reservaExistente = await _context.Reservas.AnyAsync(r =>
            r.Numero_Plaza == reserva.Numero_Plaza &&
            !(reserva.FechaFinal <= r.FechaInicio || reserva.FechaInicio >= r.FechaFinal));

            if (reservaExistente)
            {
                ModelState.AddModelError("", "Ya existe una reserva en esa plaza para las fechas seleccionadas.");
                ViewData["Id_usuario"] = new SelectList(_context.Set<IdentityUser>(), "Id", "Id", reserva.Id_usuario);
                return View(reserva);
            }
            double precioBase = 2;
            int horas = (reserva.FechaFinal - reserva.FechaInicio).Hours;
            if (horas == 0)
            {
                ViewData["Id_usuario"] = new SelectList(_context.Set<IdentityUser>(), "Id", "Id", reserva.Id_usuario);
                precioBase = 20;
                int dias = (reserva.FechaFinal - reserva.FechaInicio).Days;
                reserva.PrecioTotal = dias * precioBase;
                _context.Add(reserva);
                await _context.SaveChangesAsync();
                return RedirectToAction("Confirmacion", new { id = reserva.Id_reserva });
            }
            ViewData["Id_usuario"] = new SelectList(_context.Set<IdentityUser>(), "Id", "Id", reserva.Id_usuario);
            reserva.PrecioTotal = horas * precioBase;
            _context.Add(reserva);
            await _context.SaveChangesAsync();
            return RedirectToAction("Confirmacion", new { id = reserva.Id_reserva });

            /*
            return View(reserva);*/
        }

        // GET: reservas/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var reserva = await _context.Reservas.FindAsync(id);
            ViewData["Id_usuario"] = new SelectList(_context.Set<IdentityUser>(), "Id", "Id", reserva.Id_usuario);
            if (reserva == null)
            {
                return NotFound();
            }
            return View(reserva);
        }

        // POST: reservas/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, reserva nuevaReserva)
        {
            if (id != nuevaReserva.Id_reserva)
                return NotFound();

            var reserva = await _context.Reservas
                .FirstOrDefaultAsync(r => r.Id_reserva == id);

            if (reserva == null)
                return NotFound();
            reserva.FechaInicio = nuevaReserva.FechaInicio;
            reserva.FechaFinal = nuevaReserva.FechaFinal;
            reserva.Numero_Plaza = nuevaReserva.Numero_Plaza;
            reserva.PrecioTotal = nuevaReserva.PrecioTotal;
            int precioBase = 2;
            ViewData["Id_usuario"] = new SelectList(_context.Set<IdentityUser>(), "Id", "Id", reserva.Id_usuario);
            precioBase = 20;
            int dias = (reserva.FechaFinal - reserva.FechaInicio).Days;
            reserva.PrecioTotal = dias * precioBase;
            await _context.SaveChangesAsync();
            return View("Index");
        }

        // GET: reservas/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reserva = await _context.Reservas
                .Include(r => r.Usser)
                .FirstOrDefaultAsync(m => m.Id_reserva == id);
            if (reserva == null)
            {
                return NotFound();
            }

            return View(reserva);
        }

        // POST: reservas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var reserva = await _context.Reservas.FindAsync(id);
            if (reserva != null)
            {
                _context.Reservas.Remove(reserva);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool reservaExists(int id)
        {
            return _context.Reservas.Any(e => e.Id_reserva == id);
        }
    }
}
