﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace gestionReservasFinal.Models
{
    public class reserva
    {
        [Key]
        public int Id_reserva { get; set; }
        public int Numero_Plaza { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime FechaFinal { get; set; }
        public string Id_usuario { get; set; }
        public IdentityUser Usser { get; set; }
        public double PrecioTotal { get; set; }

    }

}
